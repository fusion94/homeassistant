const s=s=>s.substr(0,s.indexOf("."));export{s as c};
